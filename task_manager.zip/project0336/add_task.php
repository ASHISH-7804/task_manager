<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $due_date = $_POST['due_date'];

    // Insert the task into the database
    $sql = "INSERT INTO tasks (title, description, due_date) VALUES ('$title', '$description', '$due_date')";
    
    if (mysqli_query($conn, $sql)) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Task</title>
    <link rel="stylesheet" type="text/css" href="add_task.css">

    <script>
        function validateTitle() {
            const title = document.getElementById('title').value;
            if (/^\d/.test(title)) {
                alert('Title cannot start with a number!');
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }

        function validateDueDate() {
            const dueDate = document.getElementById('due_date').value;
            const today = new Date().toISOString().split('T')[0]; // Get current date in YYYY-MM-DD format
            
            if (dueDate < today) {
                alert('Due date cannot be in the past!');
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }
    </script>
</head>
<body>
    <h1>Add New Task</h1>
    <form method="POST" action="add_task.php" onsubmit="return validateTitle() && validateDueDate()">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea><br>
        <label for="due_date">Due Date:</label>
        <input type="date" id="due_date" name="due_date" required><br>
        <input type="submit" value="Add Task">
    </form>
</body>
</html>
