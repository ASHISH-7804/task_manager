<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the task details from the database
    $sql = "SELECT * FROM tasks WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $task = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $due_date = $_POST['due_date'];

        // Server-side check to ensure the due date is not in the past
       // $today = date('Y-m-d');
        //if ($due_date < $today) {
          //  echo "Error: Due date cannot be in the past!";
        //} else {
            // Update task in the database
            $update_sql = "UPDATE tasks SET title = '$title', description = '$description', due_date = '$due_date' WHERE id = $id";
            
            if (mysqli_query($conn, $update_sql)) {
                header('Location: index.php');
                exit();
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }
    }
/*}*/ else {
    echo "Task ID not provided!";
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Task</title>
    <link rel="stylesheet" type="text/css" href="add_task.css">

    <script>
        function validateTitle() {
            const title = document.getElementById('title').value;
            if (/^\d/.test(title)) {
                alert('Title cannot start with a number!');
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }

        /*function validateDueDate() {
            const dueDate = document.getElementById('due_date').value;
            const today = new Date().toISOString().split('T')[0]; // Get current date in YYYY-MM-DD format
            
            if (dueDate < today) {
                alert('Due date cannot be in the past!');
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }*/
    </script>
</head>
<body>
    <h1>Edit Task</h1>
    <form method="POST" action="edit_task.php?id=<?php echo $task['id']; ?>" onsubmit="return validateTitle()">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo $task['title']; ?>" required><br>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo $task['description']; ?></textarea><br>
        <label for="due_date">Due Date:</label>
        <input type="date" id="due_date" name="due_date" value="<?php echo $task['due_date']; ?>" required><br>
        <input type="submit" value="Update Task">
    </form>
</body>
</html>
