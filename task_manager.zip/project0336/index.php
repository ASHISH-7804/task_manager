<?php
include('db.php');

$sql = "SELECT * FROM tasks ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Task Manager</h1>
    <a href="add_task.php"><button>Add New Task</button></a>
    
    <?php
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            // Format the due date to dd/mm/yyyy
            $due_date = date("d/m/Y", strtotime($row['due_date']));

            echo "<div>";
            echo "<h3>" . $row['title'] . " (" . $row['status'] . ")</h3>";
            echo "<p>" . $row['description'] . "</p>";
            echo "<p>Due Date: " . $due_date . "</p>";
            echo "<a href='edit_task.php?id=" . $row['id'] . "'><button>Edit</button></a> | ";
            echo "<a href='delete_task.php?id=" . $row['id'] . "'><button onclick='f1(event)'>Delete</button></a>";
            echo "</div><hr>";
        }
    } else {
        echo "<p>No tasks found.</p>";
    }

    mysqli_close($conn);
    ?>

<script>
    function f1(event){
        var a = "Are you sure you want to delete this task?";
        if (confirm(a) == false) {
            event.preventDefault(); 
        }
    }
</script>

</body>
</html>
